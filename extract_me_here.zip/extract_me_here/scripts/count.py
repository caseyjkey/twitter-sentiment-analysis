import sys

print(len(sys.argv)-1)
