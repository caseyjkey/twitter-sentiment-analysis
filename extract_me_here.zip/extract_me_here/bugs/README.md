summarize() does not capture certain urls, causing missing keywords in tweets.
